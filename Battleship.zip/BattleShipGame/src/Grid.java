
public class Grid {
 protected boolean filled;
 
}
