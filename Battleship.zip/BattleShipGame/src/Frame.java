import javax.swing.JFrame;

public class Frame extends JFrame {
  public Frame() {
	  
	  this.setSize(400, 500);
	  this.setVisible(true);
  }
  public static void main (String args[]) {
		Frame frame = new Frame();
  }
}
